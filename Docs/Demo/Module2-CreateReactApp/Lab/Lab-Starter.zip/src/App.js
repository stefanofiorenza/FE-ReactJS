import React from 'react';
import './App.css';

import MainPage from './components/pages/MasterPage.jsx';


function App() {
  return (
    <div>
      <MainPage />
    </div>
  );
}

export default App;
