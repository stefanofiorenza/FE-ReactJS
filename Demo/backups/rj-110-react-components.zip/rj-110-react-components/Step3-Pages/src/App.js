import React from 'react';
import './App.css';
import MessagePage from './components/pages/MessagePage.jsx'
import ButtonPage from './components/pages/ButtonPage.jsx'

function App() {
  return (
    <div>
       {/* <MessagePage />*/}
       <ButtonPage />
    </div>
  );
}

export default App;
