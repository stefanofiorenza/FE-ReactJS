import React from 'react';
import './App.css';

function App() {
  return (
    <div className="default-text" >
      first message from React UI    
    </div>
  );
}

export default App;
