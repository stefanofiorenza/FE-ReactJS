import React from 'react';
import './App.css';
import LoginPage from './components/pages/LoginPage.jsx';
import RegistrationPage from './components/pages/RegistrationPage.jsx';


function App() {
  return (
    <div>
       {/* 
       <MessagePage />
       <LoginPage />
       */}
       <RegistrationPage />
    </div>
  );
}

export default App;
