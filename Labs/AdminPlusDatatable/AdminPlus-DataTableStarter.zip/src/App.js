import React from 'react';
import './App.css';

import MasterLayout from './components/pages/MasterLayout.jsx';

function App() {
  return (
    <div>
      <MasterLayout />
    </div>
  );
}

export default App;
